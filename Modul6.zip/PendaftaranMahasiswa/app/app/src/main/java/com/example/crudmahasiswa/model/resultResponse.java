package com.example.crudmahasiswa.model;

public class resultResponse {
    String status;
    String message;

    public String getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }
}
